local LDAFunctions = require("__LDA-LIB__/init")
local PATH = LDAFunctions.setBasePath("Quantum-Teleporter")
-- LDA.createTechnology(name, ingredients, prerequisites, unlocks, time, count, isUpgrade)
-- LDA.createTechnologyTrigger(name, unlocks, prerequisites, research_trigger)
-- LDA.createTechnologyCraftEntityTrigger(name, unlocks, prerequisites, item, count)
-- LDA.createTechnologyMineEntityTrigger(name, unlocks, prerequisites, mine_entity)
-- LDA.techUtils.createEffectsUnlocksRecipes(recipesList)

data:extend(
    {
        LDAFunctions.createTechnology(
            "Quantum-Teleporter",
            -- ingredients
            {
                {"automation-science-pack", 1},
                {"logistic-science-pack", 1},
                {"chemical-science-pack", 1},
                {"production-science-pack", 1},
                {"utility-science-pack", 1},
                {"space-science-pack", 1},
                {"metallurgic-science-pack", 1},
                {"electromagnetic-science-pack", 1},
                {"agricultural-science-pack", 1},
                {"cryogenic-science-pack", 1}
            },
            {
                "quantum-processor"
            },
            {"quantum-teleporter-equipment"},
            60,
            50
        )
    }
)

data:extend(
    {
        LDAFunctions.createTechnology(
            "Quantum-Teleporter-Portal",
            -- ingredients
            {
                {"automation-science-pack", 1},
                    {"logistic-science-pack", 1},
                    {"chemical-science-pack", 1},
                    {"production-science-pack", 1},
                    {"utility-science-pack", 1},
                    {"space-science-pack", 1},
                    {"metallurgic-science-pack", 1},
                    {"electromagnetic-science-pack", 1},
                    {"agricultural-science-pack", 1},
                    {"cryogenic-science-pack", 1}
            },
            {
                "Quantum-Teleporter"
            },
            {"part-portal-T2", "quantum-teleporter-portal-T2","quantum-teleporter-portal"},
            30,
            100
        ),
        {
            type = "technology",
            name = "Quantum-Teleporter-Portal",
            icon = PATH .. "graphics/technology/technology-portal.png",
            icon_size = 128,
            icon_mipmaps = 4,
            prerequisites = {
                "Quantum-Teleporter"
            },
            effects = {
                {
                    type = "unlock-recipe",
                    recipe = "part-portal-T2"
                },
                {
                    type = "unlock-recipe",
                    recipe = "quantum-teleporter-portal-T2"
                },
                {
                    type = "unlock-recipe",
                    recipe = "quantum-teleporter-portal"
                }
            },
            unit = {
                count = 100,
                time = 30,
                ingredients = {
                    {"automation-science-pack", 1},
                    {"logistic-science-pack", 1},
                    {"chemical-science-pack", 1},
                    {"production-science-pack", 1},
                    {"utility-science-pack", 1},
                    {"space-science-pack", 1},
                    {"metallurgic-science-pack", 1},
                    {"electromagnetic-science-pack", 1},
                    {"agricultural-science-pack", 1},
                    {"cryogenic-science-pack", 1}
                },
                order = "quantum-teleporter"
            }
        }
    }
)
